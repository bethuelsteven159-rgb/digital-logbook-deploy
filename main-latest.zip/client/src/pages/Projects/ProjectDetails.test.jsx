import { useState } from "react";
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import ProjectDetails from './ProjectDetails';

const apiMocks = vi.hoisted(() => ({
  fetchProjectDetails: vi.fn(),
  createProjectEntry: vi.fn(),
  fetchSavedFilters: vi.fn(),
  createSavedFilter: vi.fn(),
  applySavedFilter: vi.fn(),
  deleteSavedFilter: vi.fn(),
  fetchProjects: vi.fn(),
  setProjectArchived: vi.fn(),
  updateProject: vi.fn(),
  updateEntryProjectReferences: vi.fn(),
  updateEntryReferences: vi.fn(),
  updateEntry: vi.fn(),
}));

vi.mock('../../api/projectDetailsApi', () => ({
  createProjectEntry: apiMocks.createProjectEntry,
  fetchProjectDetails: apiMocks.fetchProjectDetails,
  fetchSavedFilters: apiMocks.fetchSavedFilters,
  createSavedFilter: apiMocks.createSavedFilter,
  applySavedFilter: apiMocks.applySavedFilter,
  deleteSavedFilter: apiMocks.deleteSavedFilter,
}));

vi.mock('../../api/projectsApi', () => ({
  fetchProjects: apiMocks.fetchProjects,
  setProjectArchived: apiMocks.setProjectArchived,
  updateProject: apiMocks.updateProject,
}));

vi.mock('../../api/entryFeaturesApi', () => ({
  updateEntryProjectReferences:
    apiMocks.updateEntryProjectReferences,
  updateEntryReferences:
    apiMocks.updateEntryReferences,
  updateEntry: apiMocks.updateEntry,
}));

vi.mock('../../components/Sidebar', () => ({
  default: () => (
    <div data-testid="sidebar">
      Sidebar
    </div>
  ),
}));

vi.mock('../../components/EditProjectModal', () => ({
  default: () => null,
}));

vi.mock('./NewEntryModal', () => ({
  default: ({ onClose, onCreate }) => (
    <div
      role="dialog"
      aria-label="New Entry test modal"
    >
      <button
        type="button"
        onClick={() =>
          onCreate({
            name: 'Offline entry',
            durationMinutes: 45,
            occurredAt: '2026-09-12T08:00:00Z',
            values: [],
          }).catch(() => {})
        }
      >
        Create mocked entry
      </button>

      <button
        type="button"
        onClick={onClose}
      >
        Close new entry
      </button>
    </div>
  ),
}));

vi.mock('./EntryDetailsModal', () => ({
  default: ({
    entry,
    archived,
    onClose,
    onEdit,
  }) => (
    <div
      role="dialog"
      aria-label="Entry details test modal"
    >
      <h2>{entry.name}</h2>

      <div>
        {entry.values?.length || 0} fields
      </div>

      <div>
        {entry.checklist?.length || 0} checklist items
      </div>

      <button
        type="button"
        onClick={onEdit}
        disabled={archived}
      >
        Edit entry
      </button>

      <button
        type="button"
        onClick={onClose}
      >
        Close entry
      </button>
    </div>
  ),
}));

vi.mock('./EditEntryModal', () => ({
  default: ({
    onClose,
    onSave,
  }) => {
    const [saveError, setSaveError] = useState('');
    return (
    <div
      role="dialog"
      aria-label="Edit Entry test modal"
    >
      <button
        type="button"
        onClick={() =>
          onSave({
            name: 'Updated entry',
            durationMinutes: 60,
            dueAt: null,
            fieldIds: [],
            values: [],
            newFields: [],
            checklistItems: [],
            newChecklistItems: [],
            referenceProjectIds: ['project-2'],
            referenceEntryIds: ['entry-2'],
          }).catch((error) => setSaveError(error.message))
        }
      >
        Save mocked edit
      </button>

      {saveError && <p role="alert">{saveError}</p>}
      <button
        type="button"
        onClick={onClose}
      >
        Close edit
      </button>
    </div>
  );
  },
}));

const project = {
  id: 'project-1',
  name: 'Project One',
  description: 'Test project',
  archivedAt: null,
};

const entry = {
  id: 'entry-1',
  projectId: 'project-1',
  name: 'First entry',
  durationMinutes: 30,
  occurredAt: '2026-09-10T10:00:00Z',
  dueAt: '2026-09-12T12:00:00Z',
  values: [
    {
      fieldId: 'field-1',
      name: 'Notes',
      fieldType: 'short_text',
      value: 'Example',
    },
  ],
  checklist: [
    {
      id: 'check-1',
      text: 'Write report',
      completed: false,
    },
    {
      id: 'check-2',
      text: 'Review report',
      completed: true,
    },
  ],
  references: [],
  entryReferences: [],
};

function detailsResponse(overrides = {}) {
  return {
    project: {
      ...project,
      ...overrides,
    },
    fields: [],
    entries: [entry],
    references: [],
  };
}

function renderPage() {
  return render(
    <MemoryRouter
      initialEntries={[
        '/projects/project-1',
      ]}
    >
      <Routes>
        <Route
          path="/projects/:id"
          element={<ProjectDetails />}
        />
      </Routes>
    </MemoryRouter>,
  );
}

describe('ProjectDetails entry flow', () => {
  beforeEach(() => {
    vi.clearAllMocks();

    apiMocks.fetchSavedFilters.mockResolvedValue(
      [],
    );

    apiMocks.fetchProjectDetails.mockResolvedValue(
      detailsResponse(),
    );

    apiMocks.fetchProjects.mockResolvedValue([
      project,
      {
        id: 'project-2',
        name: 'Second project',
        archivedAt: null,
      },
    ]);

    apiMocks.updateEntry.mockResolvedValue({});
    apiMocks.updateEntryProjectReferences.mockResolvedValue(
      [],
    );
    apiMocks.updateEntryReferences.mockResolvedValue(
      [],
    );
  });

  it('shows entries as clickable rows instead of inline edit buttons', async () => {
    renderPage();

    await waitFor(() =>
      expect(
        screen.getByText('First entry'),
      ).toBeInTheDocument(),
    );

    expect(
      screen.getByRole('button', {
        name: /Click entry to view full contents/i,
      }),
    ).toBeInTheDocument();

    expect(
      screen.queryByRole('button', {
        name: /^Edit entry$/i,
      }),
    ).not.toBeInTheDocument();
  });

  it('opens entry details first, then opens edit from the details view', async () => {
    const user = userEvent.setup();

    renderPage();

    await waitFor(() =>
      expect(
        screen.getByText('First entry'),
      ).toBeInTheDocument(),
    );

    await user.click(
      screen.getByRole('button', {
        name: /Click entry to view full contents/i,
      }),
    );

    expect(
      screen.getByRole('dialog', {
        name: 'Entry details test modal',
      }),
    ).toBeInTheDocument();

    expect(
      screen.getByText('2 checklist items'),
    ).toBeInTheDocument();

    await user.click(
      screen.getByRole('button', {
        name: /^Edit entry$/i,
      }),
    );

    expect(
      screen.getByRole('dialog', {
        name: 'Edit Entry test modal',
      }),
    ).toBeInTheDocument();
  });

  it('saves entry changes and updates both reference types', async () => {
    const user = userEvent.setup();

    renderPage();

    await waitFor(() =>
      expect(
        screen.getByText('First entry'),
      ).toBeInTheDocument(),
    );

    await user.click(
      screen.getByRole('button', {
        name: /Click entry to view full contents/i,
      }),
    );

    await user.click(
      screen.getByRole('button', {
        name: /^Edit entry$/i,
      }),
    );

    await user.click(
      screen.getByRole('button', {
        name: 'Save mocked edit',
      }),
    );

    await waitFor(() =>
      expect(
        apiMocks.updateEntry,
      ).toHaveBeenCalledWith(
        'project-1',
        'entry-1',
        expect.objectContaining({
          name: 'Updated entry',
          durationMinutes: 60,
          checklistItems: [],
          newChecklistItems: [],
          referenceProjectIds: ['project-2'],
          referenceEntryIds: ['entry-2'],
        }),
      ),
    );

    expect(apiMocks.updateEntry).toHaveBeenCalledTimes(1);
    expect(apiMocks.updateEntryProjectReferences).not.toHaveBeenCalled();
    expect(apiMocks.updateEntryReferences).not.toHaveBeenCalled();
    await waitFor(() => expect(apiMocks.fetchProjectDetails).toHaveBeenCalledTimes(2));
  });

  it.each(['project references', 'entry references'])('keeps the persisted entry and editor available after atomic failure in %s', async (stage) => {
    const user = userEvent.setup();
    apiMocks.updateEntry.mockRejectedValueOnce(new Error(`${stage} could not be saved`));
    renderPage();
    await screen.findByText('First entry');
    await user.click(screen.getByRole('button', { name: /Click entry to view full contents/i }));
    await user.click(screen.getByRole('button', { name: /^Edit entry$/i }));
    await user.click(screen.getByRole('button', { name: 'Save mocked edit' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(`${stage} could not be saved`);
    expect(screen.getByText('First entry')).toBeInTheDocument();
    expect(apiMocks.fetchProjectDetails).toHaveBeenCalledTimes(1);
    expect(apiMocks.updateEntryProjectReferences).not.toHaveBeenCalled();
    expect(apiMocks.updateEntryReferences).not.toHaveBeenCalled();
    // The transaction failed without persisting changes; retry uses one request.
    await user.click(screen.getByRole('button', { name: 'Save mocked edit' }));
    await waitFor(() => expect(screen.queryByRole('dialog', { name: 'Edit Entry test modal' })).not.toBeInTheDocument());
    expect(apiMocks.updateEntry).toHaveBeenCalledTimes(2);
  });

  it('keeps archived entries viewable but disables editing', async () => {
    apiMocks.fetchProjectDetails.mockResolvedValue(
      detailsResponse({
        archivedAt:
          '2026-09-11T10:00:00Z',
      }),
    );

    const user = userEvent.setup();

    renderPage();

    await waitFor(() =>
      expect(
        screen.getByText('First entry'),
      ).toBeInTheDocument(),
    );

    await user.click(
      screen.getByRole('button', {
        name: /Click entry to view full contents/i,
      }),
    );

    expect(
      screen.getByRole('dialog', {
        name: 'Entry details test modal',
      }),
    ).toBeInTheDocument();

    expect(
      screen.getByRole('button', {
        name: /^Edit entry$/i,
      }),
    ).toBeDisabled();
  });
});

describe('ProjectDetails offline capture and sync', () => {
  const offlinePayload = {
    name: 'Offline entry',
    durationMinutes: 45,
    occurredAt: '2026-09-12T08:00:00Z',
    values: [],
  };

  function readQueue() {
    return JSON.parse(
      localStorage.getItem('offlineEntryQueue') || '[]',
    );
  }

  function setOnline(value) {
    Object.defineProperty(window.navigator, 'onLine', {
      value,
      configurable: true,
    });
  }

  function goOnline() {
    setOnline(true);
    window.dispatchEvent(new Event('online'));
  }

  function goOffline() {
    setOnline(false);
    window.dispatchEvent(new Event('offline'));
  }

  async function queueEntryWhileOffline(user) {
    await user.click(
      screen.getByRole('button', {
        name: /Add New Entry/i,
      }),
    );

    await user.click(
      screen.getByRole('button', {
        name: 'Create mocked entry',
      }),
    );

    await waitFor(() =>
      expect(readQueue()).toHaveLength(1),
    );
  }

  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    setOnline(true);

    apiMocks.fetchSavedFilters.mockResolvedValue(
      [],
    );

    apiMocks.fetchProjectDetails.mockResolvedValue(
      detailsResponse(),
    );

    apiMocks.fetchProjects.mockResolvedValue([
      project,
    ]);
  });

  afterEach(() => {
    localStorage.clear();
    setOnline(true);
  });

  it('queues new entries locally while offline', async () => {
    const user = userEvent.setup();

    setOnline(false);

    renderPage();

    await screen.findByText('First entry');

    expect(
      screen.getByText(
        /new entries will be saved locally/i,
      ),
    ).toBeInTheDocument();

    await queueEntryWhileOffline(user);

    expect(
      apiMocks.createProjectEntry,
    ).not.toHaveBeenCalled();

    const [queued] = readQueue();

    expect(queued.projectId).toBe('project-1');
    expect(queued.payload).toEqual(offlinePayload);
    expect(queued.status).toBe('pending');
    expect(queued.lastError).toBeNull();
    expect(queued.localId).toBeTruthy();
  });

  it('syncs a queued entry once when the connection returns', async () => {
    const user = userEvent.setup();

    apiMocks.createProjectEntry.mockResolvedValue({
      id: 'entry-2',
    });

    setOnline(false);

    renderPage();

    await screen.findByText('First entry');

    await queueEntryWhileOffline(user);

    goOnline();

    await waitFor(() =>
      expect(
        apiMocks.createProjectEntry,
      ).toHaveBeenCalledTimes(1),
    );

    expect(
      apiMocks.createProjectEntry,
    ).toHaveBeenCalledWith('project-1', offlinePayload);

    await waitFor(() =>
      expect(readQueue()).toEqual([]),
    );

    expect(
      apiMocks.fetchProjectDetails.mock.calls.length,
    ).toBeGreaterThanOrEqual(2);

    await goOffline();

    await screen.findByText(
      /new entries will be saved locally/i,
    );

    goOnline();

    await waitFor(() =>
      expect(
        screen.queryByText(
          /new entries will be saved locally/i,
        ),
      ).not.toBeInTheDocument(),
    );

    expect(
      apiMocks.createProjectEntry,
    ).toHaveBeenCalledTimes(1);
  });

  it('keeps a failed sync queued so the entry is not lost', async () => {
    const user = userEvent.setup();

    apiMocks.createProjectEntry.mockRejectedValue(
      new Error('Server unreachable'),
    );

    renderPage();

    await screen.findByText('First entry');

    await queueEntryWhileOffline(user);

    goOffline();

    await screen.findByText(
      /new entries will be saved locally/i,
    );

    goOnline();

    await waitFor(() => {
      const [item] = readQueue();

      expect(item.status).toBe('failed');
      expect(item.lastError).toBe(
        'Server unreachable',
      );
    });

    expect(readQueue()[0].payload).toEqual(
      offlinePayload,
    );

    expect(
      screen.getByText(
        /1 entry waiting to sync/i,
      ),
    ).toBeInTheDocument();

    apiMocks.createProjectEntry.mockResolvedValue({
      id: 'entry-2',
    });

    goOffline();

    await screen.findByText(
      /new entries will be saved locally/i,
    );

    goOnline();

    await waitFor(() =>
      expect(readQueue()).toEqual([]),
    );

    // Direct attempt + failed sync + successful retry.
    expect(
      apiMocks.createProjectEntry,
    ).toHaveBeenCalledTimes(3);

    expect(
      apiMocks.createProjectEntry,
    ).toHaveBeenLastCalledWith(
      'project-1',
      offlinePayload,
    );
  });

  it('does not queue entries the server rejected', async () => {
    const user = userEvent.setup();
    const consoleError = console.error;

    console.error = vi.fn();

    const rejection = new Error(
      'Entry name is required',
    );

    rejection.status = 400;

    apiMocks.createProjectEntry.mockRejectedValue(
      rejection,
    );

    try {
      renderPage();

      await screen.findByText('First entry');

      await user.click(
        screen.getByRole('button', {
          name: /Add New Entry/i,
        }),
      );

      await user.click(
        screen.getByRole('button', {
          name: 'Create mocked entry',
        }),
      );

      await waitFor(() =>
        expect(
          apiMocks.createProjectEntry,
        ).toHaveBeenCalledTimes(1),
      );

      expect(readQueue()).toEqual([]);
    } finally {
      console.error = consoleError;
    }
  });
});